<?php
include "class.php";
session_start();


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Index PHP</title>
    <link rel="stylesheet" href="css.css">
</head>

<body>
    
    <div id="form">
        <h1>Cálculo do IMC</h1>
        <form action="" method="post">
            <fieldset>
                <legend>Dados de Usuario</legend>
                <label for="name">Nome</label>
                <br>
                <input type="text" name="name" id="name" require>
                <br>
                <label for="birthday">Data de Nascimento</label>
                <br>
                <input type="date" name="birthday" id="birthday" require>
                <br>
                <label for="gender">Sexo</label>
                <br>
                <input type="radio" name="gender" id="gender" value="male" checked>
                <label for="genderM">Masculino</label>
                <br>
                <input type="radio" name="gender" id="genderF" value="female">
                <label for="genderF">Feminino</label>
                <br>
                <label for="weight">Peso (kg)</label>
                <br>
                <input type="number" name="weight" id="weight" require>
                <br>
                <label for="height">Altura (cm)</label>
                <br>
                <input type="number" name="height" id="height" require>
            </fieldset>
            <input type="submit" name="submit" value="Enviar" style="float:right">
        </form>
    </div>
    <br>

    <div id="texto">
        <p>
            O índice de massa corporal (IMC) é uma medida internacional usada para calcular se uma pessoa está no peso ideal. Desenvolvido pelo polímata Lambert Quételet no fim do século XIX, trata-se de um método fácil e rápido para a avaliação do nível de gordura de cada pessoa, sendo, por isso, um preditor internacional de obesidade adotado pela Organização Mundial da Saúde (OMS).
        </p>
        <img src="img/eq.jpg" alt="equacao do imc" class="center">
        <img src="img/Untitled.png" alt="tabela imc" class="center">
    </div>

    <div id="php">
        <?php
        if (isset($_POST["submit"])) {
            $_SESSION["name"]     = $_POST["name"];
            $_SESSION["birthday"] = $_POST["birthday"];
            $_SESSION["gender"]   = $_POST["gender"];
            $_SESSION["weight"]   = $_POST["weight"];
            $_SESSION["height"]   = $_POST["height"];

            $w = $_SESSION["weight"];
            $h = $_SESSION["height"];
            $imc = $w / (pow($h / 100, 2));

            if (($imc) < 18.5)
                $categoria = "Abaixo do peso <br>";
            if (($imc) >= 18.5 and ($imc) < 25.0)
                $categoria = "Peso Normal <br>";
            if (($imc) >= 25.0 and ($imc) < 30.0)
                $categoria = "Sobrepeso <br>";
            if (($imc) >= 30.0 and ($imc) < 35.0)
                $categoria = "Obesidade Grau I <br>";
            if (($imc) >= 35.0 and ($imc) < 40.0)
                $categoria = "Obesidade Grau II <br>";
            if (($imc) >= 40.0)
                $categoria = "Obesidade Grau III <br>";


            print("<br>Dados armazenados<br>");

            $user = new user(
                $_SESSION["name"],
                $_SESSION["birthday"],
                $_SESSION["gender"],
                $_SESSION["weight"],
                $_SESSION["height"],
                $imc,
                $categoria
            );

            $_SESSION["lista"][] = $user;
            $lista = $_SESSION["lista"];

            foreach ($lista as $i) {
                echo "<br>Nome: " . $i->name . " |  Genero: " . $i->gender . " |  Peso: " . $i->weight . "kg" . " |  Altura: " . $i->height . "cm" . " |  IMC: " . round($i->imc, 2). " |  Categoria: ".$i->categoria;
            }

            $i = 0;
            $avgIMC = 0;
            foreach ($lista as $i) {
                $avgIMC += $i->imc;
            }

            $avgIMC =  $avgIMC / count($lista);
            echo "<br><br>Valor medio  do IMC: " . round($avgIMC, 2);
            if (($avgIMC) < 18.5)
                print("<br>Abaixo do peso <br>");
            if (($avgIMC) >= 18.5 and ($avgIMC) < 25.0)
                print("<br>Peso Normal <br>");
            if (($avgIMC) >= 25.0 and ($avgIMC) < 30.0)
                print("<br>Sobrepeso <br>");
            if (($avgIMC) >= 30.0 and ($avgIMC) < 35.0)
                print("<br>Obesidade Grau I <br>");
            if (($avgIMC) >= 35.0 and ($avgIMC) < 40.0)
                print("<br>Obesidade Grau II <br>");
            if (($avgIMC) >= 40.0)
                print("<br>Obesidade Grau III <br>");
        }
        ?>
    </div>

</body>

</html>