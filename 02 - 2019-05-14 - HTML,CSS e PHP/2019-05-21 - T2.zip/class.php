<?php

class User {
    public $name;
    public $birthday;
    public $gender;
    public $weight;
    public $height;

    function __construct($name,$birthday,$gender,$weight,$height,$imc, $categoria){
        $this->name     = $name;
        $this->birthday = $birthday;
        $this->gender   = $gender;
        $this->weight   = $weight;
        $this->height   = $height;
        $this->imc      = $imc;
        $this->categoria = $categoria;
    }

    function cat($weight,$height){
        $imc = $weight / (pow($height/100, 2));
        echo "<br>Valor IMC: " .round( $imc,2) . "<br>";
        if ($imc < 18.5) 
            print( "Abaixo do peso <br>"); 
        if ($imc>= 18.5 and $imc < 25.0)
            print( "Peso Normal <br>"); 
        if ($imc>= 25.0 and $imc < 30.0)
            print( "Sobrepeso <br>"); 
        if ($imc>= 30.0 and $imc < 35.0)
            print( "Obesidade Grau I <br>"); 
        if ($imc>= 35.0 and $imc < 40.0)
            print( "Obesidade Grau II <br>"); 
        if ($imc>= 40.0)
            print( "Obesidade Grau III <br>");

        return $imc;
    }
}